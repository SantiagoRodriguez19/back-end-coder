/**
 * TS Savastano Federico
 * Desafio 02
 *
 * el codigo en .ts se encuentra en la carpeta src, y el codigo compilado en la carpeta product
 * el proyecto tiene instalado el compilador de typescript, con lo que se debe ejecutar el comando tsc para generar los js
 *
 * Tuve dudas con el enunciado del desafio, me resultó confuso cual debia ser operacion y cual operaciones.
 * No se si hay un error ahi, o me confundí yo.
 * Tomé como "operaciones" al que tiene el metodo que devuelve suma o resta
 * y "operación" al que hace la llamada y se le introducen los parametros.
 * El punto referido a las clases no lo realicé, siendo que era opcional y que no hay material explicando esta parte, ni se vio en clase.
 */
